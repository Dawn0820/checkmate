package com.kh.checkmate.studyGroupMember.model.service;

import java.util.Map;

public interface StudyGroupMemberService {

	int insertStudyGroupMember(Map<String, Object> map);

}
