package com.kh.checkmate.studyGroupMember.model.vo;

import lombok.Data;

@Data
public class StudyGroupMember {
	private int sgmNo;
	private String sgmNick;
	private int smgSgNo;
}
