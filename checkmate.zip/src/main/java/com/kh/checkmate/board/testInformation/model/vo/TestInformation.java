package com.kh.checkmate.board.testInformation.model.vo;

public class TestInformation {

}
