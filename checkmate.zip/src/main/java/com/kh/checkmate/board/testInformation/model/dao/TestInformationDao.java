package com.kh.checkmate.board.testInformation.model.dao;

public class TestInformationDao {

}
