package com.kh.checkmate.board.testInformation.model.service;

public interface TestInformationService {

}
