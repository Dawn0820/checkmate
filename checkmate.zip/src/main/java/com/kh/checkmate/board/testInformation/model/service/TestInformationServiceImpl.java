package com.kh.checkmate.board.testInformation.model.service;

public class TestInformationServiceImpl implements TestInformationService{

}
