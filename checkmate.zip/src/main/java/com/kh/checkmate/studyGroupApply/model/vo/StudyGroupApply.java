package com.kh.checkmate.studyGroupApply.model.vo;

import lombok.Data;

@Data
public class StudyGroupApply {
	private int sgApplyNo;
	private String sgApplyNick;
	private String sgApplySgNo;
	private String sgApplyContent;
}
